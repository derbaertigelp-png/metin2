#!/usr/bin/env python3
"""
Metin2 Update Server - File List Generator
Dieses Script generiert die filelist.json für den Update-Server
"""

import os
import json
import hashlib
from pathlib import Path

# Konfiguration
CLIENT_DIR = r"C:\Users\Anwender\Desktop\Metin2\[40250] Reference Serverfile-20260129T192822Z-3-001\[40250] Reference Serverfile\Client"  # Passe dies an deinen Client-Pfad an
OUTPUT_FILE = "filelist.json"

# Dateien/Ordner die NICHT überwacht werden sollen
EXCLUDE_PATTERNS = [
    "*.log",
    "*.txt",
    "Screenshot*",
    "__cache__",
    "errorlog.txt",
    "metin2.cfg",
    "ServerList.txt",
    "*.pyc"
]

# Dateien die IMMER überwacht werden sollen
INCLUDE_FILES = [
    "metin2client.bin",
    "*.dll",
    "*.exe",
    "pack/*.epk",
    "pack/*.eix",
    "locale_de/*.txt"
]


def calculate_md5(file_path):
    """Berechnet den MD5-Hash einer Datei"""
    hash_md5 = hashlib.md5()
    try:
        with open(file_path, "rb") as f:
            for chunk in iter(lambda: f.read(4096), b""):
                hash_md5.update(chunk)
        return hash_md5.hexdigest()
    except Exception as e:
        print(f"Fehler beim Hashen von {file_path}: {e}")
        return None


def should_include_file(file_path, base_dir):
    """Prüft ob eine Datei inkludiert werden soll"""
    relative_path = os.path.relpath(file_path, base_dir)
    
    # Prüfe Exclude-Patterns
    for pattern in EXCLUDE_PATTERNS:
        if pattern.startswith("*"):
            if file_path.endswith(pattern[1:]):
                return False
        else:
            if pattern in relative_path:
                return False
    
    return True


def generate_file_list(client_dir):
    """Generiert die Liste aller zu prüfenden Dateien"""
    file_list = []
    
    print(f"Scanne Verzeichnis: {client_dir}")
    
    for root, dirs, files in os.walk(client_dir):
        for file in files:
            full_path = os.path.join(root, file)
            
            if not should_include_file(full_path, client_dir):
                continue
            
            relative_path = os.path.relpath(full_path, client_dir)
            file_size = os.path.getsize(full_path)
            file_hash = calculate_md5(full_path)
            
            if file_hash is None:
                continue
            
            file_info = {
                "Path": relative_path.replace("/", "\\"),
                "Hash": file_hash,
                "Size": file_size
            }
            
            file_list.append(file_info)
            print(f"  + {relative_path} ({file_size} bytes)")
    
    return file_list


def save_file_list(file_list, output_file):
    """Speichert die Dateiliste als JSON"""
    with open(output_file, "w", encoding="utf-8") as f:
        json.dump(file_list, f, indent=2, ensure_ascii=False)
    
    print(f"\n✓ Dateiliste gespeichert: {output_file}")
    print(f"✓ Anzahl Dateien: {len(file_list)}")
    total_size = sum(f["Size"] for f in file_list)
    print(f"✓ Gesamtgröße: {total_size / 1024 / 1024:.2f} MB")


def main():
    """Hauptfunktion"""
    if not os.path.exists(CLIENT_DIR):
        print(f"FEHLER: Client-Verzeichnis nicht gefunden: {CLIENT_DIR}")
        print("Bitte passe CLIENT_DIR im Script an!")
        return
    
    print("=" * 60)
    print("Metin2 Update Server - File List Generator")
    print("=" * 60)
    
    file_list = generate_file_list(CLIENT_DIR)
    save_file_list(file_list, OUTPUT_FILE)
    
    print("\n✓ Fertig! Lade filelist.json auf deinen Update-Server hoch.")
    print(f"  URL: http://update.metin2-flix.de/filelist.json")


if __name__ == "__main__":
    main()
